<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('archive', function (Blueprint $table) {
            $table->integer('archive_number')->primary(); // Patient's record ID (manual entry)

            // Patient information
            $table->string('last_name_father', 45)->nullable();
            $table->string('last_name_mother', 45)->nullable();
            $table->string('name', 45)->nullable();
            $table->string('age', 45)->nullable();
            $table->tinyInteger('gender')->nullable(); // 0 = Male, 1 = Female, etc.
            $table->string('classification', 45)->nullable();

            // Emergency contact
            $table->string('contact_last_name_father', 45)->nullable();
            $table->string('contact_last_name_mother', 45)->nullable();
            $table->string('contact_name', 45)->nullable();

            // Additional details
            $table->date('admission_date')->nullable();
            $table->string('address', 45)->nullable();
            $table->string('locality', 45)->nullable();
            $table->string('municipality', 45)->nullable();
            $table->char('trial304', 1)->nullable();

            // Timestamps and soft delete
            $table->timestamps();    // created_at and updated_at
            $table->softDeletes();   // deleted_at
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('records');
    }
};
